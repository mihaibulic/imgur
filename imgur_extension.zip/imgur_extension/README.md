imgur
=====

This Chrome extension makes imgur work better :)
